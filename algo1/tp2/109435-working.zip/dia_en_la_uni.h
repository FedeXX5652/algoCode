#ifndef __DIA_EN_LA_UNI__
#define __DIA_EN_LA_UNI__

#define STITCH_ID 'S'
#define JASMIN_ID 'J'
#define RAYO_ID 'R'
#define OLAF_ID 'O'

char elegir_personaje();

#endif // __DIA_EN_LA_UNI__